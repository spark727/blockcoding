# GiGA Genie AI Makers Kit
 
 
GiGA Genie AI Maker Kit SDK를 응용하여
AMK응용하기에 사용된 예제 입니다.


### Directory

    amk_DHT11.py                : DHT11 온도센서를 사용하여 기가지니에 음성으로 온도와 습도값을 음성 출력받을 수 있습니다.
    amk_led_controle.py         : AMK 키트에 장착되어 있는 스위치의 LED를 음성으로 제어할 수 있습니다.
    amk_youtube_audio_stream.py : 음성 명령으로 유튜브 영상의 오디오를 출력해줄 수 있습니다.
    README.md                   : 현재 파일
