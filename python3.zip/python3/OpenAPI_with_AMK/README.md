# OpenAPI_with_AMK
AMK를 이용하여 공공데이터 포털의 미세먼지 값을 출력

### Directory

    AMK_dust_info.py            : 음성명령으로 각 지역의 미세먼지 정보를 받아와서 음성으로 출력해주는 예제입니다.
    sidoCityName.json           : API와 함께 사용하기 위해서 대한민국의 시,도 / 시,군,구 가 정리되어 있는 json 파일 입니다.
    README.md                   : 현재 파일
